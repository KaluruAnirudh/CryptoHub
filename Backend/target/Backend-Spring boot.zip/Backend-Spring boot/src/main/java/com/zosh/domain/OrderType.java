
package com.ani.domain;

public enum OrderType {
    BUY,
    SELL
}
