package com.ani.request;

import lombok.Data;

@Data
public class PromptBody {
    private String prompt;
}
