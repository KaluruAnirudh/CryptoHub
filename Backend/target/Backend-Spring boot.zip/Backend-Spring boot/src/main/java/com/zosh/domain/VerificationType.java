package com.ani.domain;

public enum VerificationType {
    MOBILE,
    EMAIL
}
