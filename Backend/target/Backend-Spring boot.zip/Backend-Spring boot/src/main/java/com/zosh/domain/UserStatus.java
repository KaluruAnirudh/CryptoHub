package com.ani.domain;

public enum UserStatus {

    VERIFIED,
    PENDING

}
