package com.ani.domain;

public enum PaymentOrderStatus {
    PENDING,SUCCESS,FAILED
}
