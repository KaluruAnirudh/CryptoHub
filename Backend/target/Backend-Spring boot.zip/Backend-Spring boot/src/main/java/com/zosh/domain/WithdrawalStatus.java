package com.ani.domain;

public enum WithdrawalStatus {
    PENDING,
    SUCCESS,
    DECLINE
}
