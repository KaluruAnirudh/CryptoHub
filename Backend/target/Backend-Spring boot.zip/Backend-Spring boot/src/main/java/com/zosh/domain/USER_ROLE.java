package com.ani.domain;

public enum USER_ROLE {
    ROLE_ADMIN, ROLE_USER
}
