package com.ani.domain;

public enum PaymentMethod {
    RAZORPAY,
    STRIPE
}
